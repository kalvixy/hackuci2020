﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class Controller: MonoBehaviour
{
    public void LoadByIndex(int nextLevel)
    {
        SceneManager.LoadScene(nextLevel);
    }
}