﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraScript : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        GetComponent<Camera>().orthographicSize = 50; // Size u want to start with
    }

    // Update is called once per frame
    void Update()
    {
        GetComponent<Camera>().orthographicSize = GetComponent<Camera>().orthographicSize - 45 * Time.deltaTime / 3;
        if (GetComponent<Camera>().orthographicSize < 6)
        {
            GetComponent<Camera>().orthographicSize = 6;
        }
    }
}