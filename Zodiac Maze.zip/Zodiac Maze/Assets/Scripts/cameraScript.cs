﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class cameraScript : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        int y = SceneManager.GetActiveScene().buildIndex; //get current scene index
        Debug.Log(y + " scene loaded");
        switch (y)
        {
            case 1:
                GetComponent<Camera>().orthographicSize = 60; // Size u want to start with      
                break;
            case 2:
                GetComponent<Camera>().orthographicSize = 70; // Size u want to start with
                break;
            case 3:
                GetComponent<Camera>().orthographicSize = 80; // Size u want to start with
                break;
            case 4:
                GetComponent<Camera>().orthographicSize = 85; // Size u want to start with
                break;
            case 5:
                GetComponent<Camera>().orthographicSize = 80; // Size u want to start with
                break;
            case 6:
                GetComponent<Camera>().orthographicSize = 75; // Size u want to start with
                break;
            case 7:
                GetComponent<Camera>().orthographicSize = 75; // Size u want to start with
                break;
            case 8:
                GetComponent<Camera>().orthographicSize = 75; // Size u want to start with
                break;
            case 9:
                GetComponent<Camera>().orthographicSize = 75; // Size u want to start with
                break;
            case 10:
                GetComponent<Camera>().orthographicSize = 60; // Size u want to start with
                break;
            case 11:
                GetComponent<Camera>().orthographicSize = 70; // Size u want to start with
                break;
            default:
                GetComponent<Camera>().orthographicSize = 60; // Size u want to start with
                break;
        }
    }

    // Update is called once per frame
    void Update()
    {
        GetComponent<Camera>().orthographicSize = GetComponent<Camera>().orthographicSize - 45 * Time.deltaTime / 4;
        if (GetComponent<Camera>().orthographicSize < 6)
        {
            GetComponent<Camera>().orthographicSize = 6;
        }
    }
}